import logging

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status

from app.core.config import settings
from app.core.limiter import limiter
from app.core.security import current_provider
from app.services import icd10, places, prognosis
from app.services.prognosis import PrognosisAuthError

logger = logging.getLogger(__name__)
audit = logging.getLogger("rxhub.audit")

router = APIRouter(prefix="/lookup", tags=["lookup"], dependencies=[Depends(current_provider)])


@router.get("/enrollee")
@limiter.limit("60/minute")
async def enrollee(request: Request, enrollee_id: str = Query(..., alias="enrollee_id", max_length=64),
                   provider: dict = Depends(current_provider)):
    """Verify enrollee against Prognosis. Requires PROGNOSIS_USERNAME /
    PASSWORD. Falls back to a stub in dev when those aren't configured so
    the frontend flow can still be clicked through.
    """
    audit.info("event=enrollee_lookup actor=%s target=%s", provider.get("sub", "?"), enrollee_id)
    if (settings.prognosis_username and settings.prognosis_password) or settings.prognosis_auth_header:
        try:
            data = await prognosis.verify_enrollee(enrollee_id)
        except PrognosisAuthError as e:
            logger.warning("Prognosis verify failed: %s", e)
            raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=f"Prognosis verify failed: {e}")
        if data is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Enrollee not found")
        return data

    # Dev fallback (no Prognosis credentials set).
    return {
        "enrollee_id": enrollee_id,
        "name": "Adaeze Okafor",
        "scheme": "Leadway Premium",
        "company": "Leadway Health",
        "age": 42,
        "phone": "08012345678",
        "email": "adaeze@example.com",
        "state": "Lagos",
        "status": "Active",
        "expiry_date": "2026-12-31",
        "flag": "green",
        "flag_reason": None,
        "vip": False,
        "medications": [
            {"name": "Amlodipine 10mg", "generic": "Amlodipine", "dosage": "10mg OD", "quantity": 30,
             "classification": "chronic", "next_refill": "2026-05-03"},
            {"name": "Metformin 500mg", "generic": "Metformin", "dosage": "500mg BD", "quantity": 60,
             "classification": "chronic", "next_refill": "2026-05-10"},
        ],
    }


@router.get("/diagnoses")
@limiter.limit("120/minute")
async def diagnoses(request: Request, q: str = Query(default="", min_length=0, max_length=100), limit: int = Query(default=20, ge=1, le=100)):
    """Standard ICD-10 search backed by the embedded catalog in app.services.icd10."""
    return icd10.search(q, limit=limit)


@router.get("/address-autocomplete")
@limiter.limit("60/minute")
async def address_autocomplete(request: Request, input: str = Query(..., max_length=200)):
    """Google Places autocomplete (Nigeria-scoped). Falls back to inline stubs
    when GOOGLE_MAPS_API_KEY is unset so the wizard works in dev.
    """
    return await places.autocomplete(input)


@router.get("/address-details")
@limiter.limit("60/minute")
async def address_details(request: Request, place_id: str = Query(..., max_length=500)):
    """Google Place details + geometry. Same fallback behavior as autocomplete."""
    return await places.details(place_id)
