// ═════════════════════════════════════════════════════════════════════
//  EDIT THIS FILE BEFORE DEPLOYMENT
// ═════════════════════════════════════════════════════════════════════
//  Replace the URL below with YOUR backend's Azure App Service URL,
//  with "/api/v1" appended at the end. Example:
//
//    window.__API_BASE__ = "https://rxhub-api-prod.azurewebsites.net/api/v1";
//
//  This is the ONLY file you need to edit in the frontend package.
// ═════════════════════════════════════════════════════════════════════

window.__API_BASE__ = "https://REPLACE-WITH-YOUR-BACKEND-URL.azurewebsites.net/api/v1";
